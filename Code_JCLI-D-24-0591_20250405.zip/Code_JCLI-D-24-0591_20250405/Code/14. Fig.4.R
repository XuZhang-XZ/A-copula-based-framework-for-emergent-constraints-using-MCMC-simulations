

# Plot Fig.4 ------------------------------------------------------

## Colors
Sel_Colors = brewer.pal(9,"Set1")

## Data
Final_EC = read.csv("Output Data/CMIP6/tas/Final.series_EC.csv",row.names = 1)

## Plot
p1 = ggplot() +
  geom_abline(intercept = 0, slope = 1, color = Sel_Colors[2], linewidth = 0.5, linetype = "dashed") +
  geom_point(data = Final_EC,
             aes(x = Copula_Prob_x1, y = Empri_Prob_x1))+
  scale_x_continuous(name = "Theoretical probability") +
  scale_y_continuous(name = "Empirical probability") +
  theme_figure1+
  coord_cartesian(xlim = c(0,1), ylim = c(0,1),expand = FALSE)+
  theme(
    plot.margin = margin(10, 20, 10, 10, "pt"),
    legend.position = "inside",
    legend.justification.inside = c(0.12,0.85)
  )

## Plot
p2 = ggplot() +
  geom_abline(intercept = 0, slope = 1, color = Sel_Colors[2], linewidth = 0.5, linetype = "dashed") +
  geom_point(data = Final_EC,
             aes(x = Copula_Prob_x2, y = Empri_Prob_x2))+
  scale_x_continuous(name = "Theoretical probability") +
  scale_y_continuous(name = "Empirical probability") +
  theme_figure1+
  coord_cartesian(xlim = c(0,1), ylim = c(0,1),expand = FALSE)+
  theme(
    plot.margin = margin(10, 20, 10, 10, "pt"),
    legend.position = "inside",
    legend.justification.inside = c(0.12,0.85)
  )

## Total Plot
p.total = plot_grid(p1, p2, labels = "auto", nrow = 1)

## Saving
ggsave(
  filename = "Figures/Fig_4.pdf",
  plot = p.total,
  device = cairo_pdf,
  width = 8,
  height = 4
)

# End -------------------------------------------------------------

