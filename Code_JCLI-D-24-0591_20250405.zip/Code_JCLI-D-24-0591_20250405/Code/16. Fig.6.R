

# Plot Fig. 6 ------------------------------------------------------------

## Read
HEC_MCMC = read.csv("Output Data/CMIP6_EC/EC.summary/HEC_MCMC.csv",row.names = 1)
HEC_Summary = read.csv("Output Data/CMIP6_EC/Summary/HEC_Summary.csv",row.names = 1)
Sel_Colors = c("red",brewer.pal(8,"Dark2")[c(1,2)])

## HEC_Future
Sim_Density = data.frame("X_Value" = seq(0,10,length.out = 1000))
Sim_Density$D1.HEC = dnorm(Sim_Density$X_Value,mean = HEC_Summary$Future_mean_EC[1],sd = HEC_Summary$Future_Var_EC[1]^0.5)

## Mean and SD
CEC_Two_Sel = subset(HEC_MCMC, CEC == "x_1")
Vel_mean = c(HEC_Summary$Future_mean_EC[1],mean(CEC_Two_Sel$y_1))
Vel_Var = c(HEC_Summary$Future_Var_EC[1], var(CEC_Two_Sel$y_1))

## Print
Vel_mean1 = sprintf("%.3f", round(Vel_mean,3))
Vel_Var1 = sprintf("%.3f", round(Vel_Var,3))

## Plot TAS.var.His
p1 = ggplot() +
  geom_histogram(
    data = CEC_Two_Sel,
    breaks = seq(0,10,0.25),
    fill = Sel_Colors[3],
    color = "#e9ecef",
    alpha = 0.5,
    aes(x = y_1, y = after_stat(density))
  ) +
  geom_path(
    data = Sim_Density,
    color = Sel_Colors[2],
    linewidth = 1,
    aes(x = X_Value, y = D1.HEC)
  ) +
  geom_vline(xintercept = Vel_mean[1], color = Sel_Colors[1],linewidth = 1)+
  geom_vline(xintercept = Vel_mean[2], color = Sel_Colors[2],linewidth = 1)+
  annotate("text", x = Inf, y = -Inf, hjust = 1.3, vjust = -10.5, label = "Mean", color = "black")+
  annotate("text", x = Inf, y = -Inf, hjust = 1.3, vjust = -9.0, label = Vel_mean1[2], color = Sel_Colors[3])+
  annotate("text", x = Inf, y = -Inf, hjust = 1.3, vjust = -7.5, label = Vel_mean1[1], color = Sel_Colors[2])+
  annotate("text", x = Inf, y = -Inf, hjust = 1.3, vjust = -4.5, label = "Var ", color = "black")+
  annotate("text", x = Inf, y = -Inf, hjust = 1.3, vjust = -3.0, label = Vel_Var1[2], color = Sel_Colors[3])+
  annotate("text", x = Inf, y = -Inf, hjust = 1.3, vjust = -1.5, label = Vel_Var1[1], color = Sel_Colors[2])+
  scale_x_continuous(name = expression("2081-2100 "*Delta*italic(T["GL"])*" (°C relative to 1850-1900)")) +
  scale_y_continuous(name = "Probability density",breaks = seq(0,0.6,0.1)) +
  theme_figure1+
  coord_cartesian(xlim = c(1,10), ylim = c(0,0.6),expand = FALSE)+
  theme(
    plot.margin = margin(10, 15, 5, 10, "pt"),
    legend.position = "none"
  )


## HEC_Future
Sim_Density = data.frame("X_Value" = seq(0,10,length.out = 1000))
Sim_Density$D1.HEC = dnorm(Sim_Density$X_Value,mean = HEC_Summary$Future_mean_EC[2],sd = HEC_Summary$Future_Var_EC[2]^0.5)

## Mean and SD
CEC_Two_Sel = subset(HEC_MCMC, CEC == "x_2")
Vel_mean = c(HEC_Summary$Future_mean_EC[2],mean(CEC_Two_Sel$y_1))
Vel_Var = c(HEC_Summary$Future_Var_EC[2], var(CEC_Two_Sel$y_1))

## Print
Vel_mean1 = sprintf("%.3f", round(Vel_mean,3))
Vel_Var1 = sprintf("%.3f", round(Vel_Var,3))

## Plot TAS.var.His
p2 = ggplot() +
  geom_histogram(
    data = CEC_Two_Sel,
    breaks = seq(0,10,0.25),
    fill = Sel_Colors[3],
    color = "#e9ecef",
    alpha = 0.5,
    aes(x = y_1, y = after_stat(density))
  ) +
  geom_path(
    data = Sim_Density,
    color = Sel_Colors[2],
    linewidth = 1,
    aes(x = X_Value, y = D1.HEC)
  ) +
  geom_vline(xintercept = Vel_mean[1], color = Sel_Colors[1],linewidth = 1)+
  geom_vline(xintercept = Vel_mean[2], color = Sel_Colors[2],linewidth = 1)+
  annotate("text", x = Inf, y = -Inf, hjust = 1.3, vjust = -10.5, label = "Mean", color = "black")+
  annotate("text", x = Inf, y = -Inf, hjust = 1.3, vjust = -9.0, label = Vel_mean1[2], color = Sel_Colors[3])+
  annotate("text", x = Inf, y = -Inf, hjust = 1.3, vjust = -7.5, label = Vel_mean1[1], color = Sel_Colors[2])+
  annotate("text", x = Inf, y = -Inf, hjust = 1.3, vjust = -4.5, label = "Var ", color = "black")+
  annotate("text", x = Inf, y = -Inf, hjust = 1.3, vjust = -3.0, label = Vel_Var1[2], color = Sel_Colors[3])+
  annotate("text", x = Inf, y = -Inf, hjust = 1.3, vjust = -1.5, label = Vel_Var1[1], color = Sel_Colors[2])+
  scale_x_continuous(name = expression("2081-2100 "*Delta*italic(T["GL"])*" (°C relative to 1850-1900)")) +
  scale_y_continuous(name = "Probability density",breaks = seq(0,0.6,0.1)) +
  theme_figure1+
  coord_cartesian(xlim = c(1,10), ylim = c(0,0.6),expand = FALSE)+
  theme(
    plot.margin = margin(10, 15, 5, 10, "pt"),
    legend.position = "none"
  )

## Legend
p.legend.1 = ggplot() +
  geom_path(data = data.frame(
    "x" = 1,
    "y" = 1,
    type = c("Analytical equations in HEC", "MCMC simulations for HEC")
  ), 
  aes(x = x, y = y , color = type)) +
  scale_color_manual(
    breaks = c("Analytical equations in HEC", "MCMC simulations for HEC"),
    values = Sel_Colors[c(2, 3)]
  ) +
  theme_figure1+
  theme(
    legend.position = "top",
    legend.justification.top = c(0.5,0.5),
    legend.direction = "vertical"
  )
legend1 = cowplot::get_plot_component(p.legend.1, 'guide-box-top', return_all = TRUE)

## Combine
p2 = p2+annotation_custom(legend1, xmin = 6, ymin = 0.45)

## Total Plot
p.total = plot_grid(p1,p2,
                    labels = "auto",nrow = 1)

## Saving
ggsave(filename = "Figures/Fig_6.pdf",
       plot = p.total,
       device = cairo_pdf,
       width = 9, 
       height = 4)

# End ---------------------------------------------------------------------


