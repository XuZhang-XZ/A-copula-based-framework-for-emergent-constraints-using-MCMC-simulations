
## Data
Final_EC = read.csv("Output Data/CMIP6_EC/Summary/Final_EC.csv",row.names = 1,check.names = FALSE)

## Select
Final_EC_Target = Final_EC %>%
  dplyr::rename(
    "Global" = "Future_GL",
    "90°S-60°S" = "His_S_-60",
    "90°S-50°S" = "His_S_-50",
    "90°S-40°S" = "His_S_-40",
    "90°S-30°S" = "His_S_-30",
    "90°S-20°S" = "His_S_-20",
    "90°S-10°S" = "His_S_-10",
    "90°S-0°S" = "His_S_0",
    "90°N-0°N" = "His_N_0",
    "90°N-10°N" = "His_N_10",
    "90°N-20°N" = "His_N_20",
    "90°N-30°N" = "His_N_30",
    "90°N-40°N" = "His_N_40",
    "90°N-50°N" = "His_N_50",
    "90°N-60°N" = "His_N_60"
  ) %>%
  dplyr::select(
    "Global",
    "90°S-60°S","90°S-50°S","90°S-40°S","90°S-30°S","90°S-20°S","90°S-10°S","90°S-0°S",
    "90°N-60°N","90°N-50°N","90°N-40°N","90°N-30°N","90°N-20°N","90°N-10°N","90°N-0°N",
  )

## Correlations
T_Var_cor = round(cor(Final_EC_Target),3)
T_Var_cor[lower.tri(T_Var_cor)] <- NA

## Summary
library(reshape2)
melted_cormat <- melt(T_Var_cor, na.rm = TRUE)
melted_cormat$Sig = ifelse(melted_cormat$value > 0.335,"*","")
melted_cormat$value_text = paste0(melted_cormat$value,melted_cormat$Sig)

## Plot
p1 = ggplot(data = melted_cormat, aes(Var2, Var1, fill = value)) +
  geom_tile(color = "white") +
  geom_text(aes(Var2, Var1, label = value_text),
            color = "black",size = 3.5) +
  scale_fill_gradientn(
    colors = brewer.pal(11,"Spectral"),
    limit = c(-0.8, 0.8),
    space = "Lab",
    name = "Pearson Correlation",
    oob = scales::squish
  ) +
  guides(fill = guide_colorbar(
    barwidth = 15,
    barheight = 1,
    title.position = "top",
    title.hjust = 0.5
  )) +
  theme(
    axis.title.x = element_blank(),
    axis.title.y = element_blank(),
    axis.text.x = element_text(angle = 30,hjust = 1,vjust = 1.1,color = "black"),
    axis.text.y = element_text(color = "black"),
    panel.grid.major = element_blank(),
    panel.border = element_blank(),
    panel.background = element_blank(),
    axis.ticks = element_blank(),
    legend.position = "inside",
    legend.position.inside = c(0.3,0.8),
    legend.direction = "horizontal",
    legend.key.width = unit(100,"pt"),
    legend.ticks = element_line(color = "gray50"),
    legend.frame = element_rect(color = "gray50")
  )
p1

## Saving
ggsave(filename = "Figures/Fig_1.pdf",
       plot = p1,
       device = cairo_pdf,
       width = 9, 
       height = 6)

# End ---------------------------------------------------------------------


