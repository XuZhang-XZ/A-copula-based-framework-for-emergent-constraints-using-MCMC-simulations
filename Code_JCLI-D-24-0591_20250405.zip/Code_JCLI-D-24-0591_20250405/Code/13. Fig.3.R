

# Fig. 2 ---------------------------------------------------------------------

## Colors
Sel_Colors = brewer.pal(9,"Set1")

## Data
Final_EC = read.csv("Output Data/CMIP6/tas/Final.series_EC.csv",row.names = 1)
Univariate.best = read.csv("Output Data/CMIP6/tas/Univariate.best.csv",row.names = 1)

## x_1
Sim_Density = data.frame("X_value" = seq(0,1,length.out = 1000))
Sim_Density$D1 = Marignal.distribution(x = Sim_Density$X_value, Type = "d", Num = "x_1")

## Plot
p1 = ggplot() +
  geom_histogram(
    data = Final_EC,
    binwidth = 0.07,
    fill = Sel_Colors[3],
    color = "#e9ecef",
    alpha = 0.6,
    aes(x = x_1, y = after_stat(density))
  ) +
  geom_path(data = Sim_Density,color = Sel_Colors[2],
            aes(x = X_value, y = D1))+
  scale_x_continuous(name =  expression("1984-2014 " * italic(T["Trend,SH"]) * " (°C per decade)")) +
  scale_y_continuous(name = "Probability density") +
  theme_figure1+
  coord_cartesian(xlim = c(0,0.8), ylim = c(0,6),expand = FALSE)+
  theme(
    plot.margin = margin(7, 10, 7, 10, "pt"),
    legend.position = "inside",
    legend.justification.inside = c(0.98,0.92)
  )

## x_2
Sim_Density = data.frame("X_value" = seq(0,1,length.out = 1000))
Sim_Density$D1 = Marignal.distribution(x = Sim_Density$X_value, Type = "d", Num = "x_2")

## Plot
p2 = ggplot() +
  geom_histogram(
    data = Final_EC,
    binwidth = 0.04,
    fill = Sel_Colors[3],
    color = "#e9ecef",
    alpha = 0.6,
    aes(x = x_2, y = after_stat(density))
  ) +
  geom_path(data = Sim_Density, color = Sel_Colors[2], aes(x = X_value, y = D1)) +
  scale_x_continuous(name =  expression("1984-2014 " * italic(T["Trend,SH"]) * " (°C per decade)")) +
  scale_y_continuous(name = "Probability density") +
  theme_figure1+
  coord_cartesian(xlim = c(0,0.5), ylim = c(0,10),expand = FALSE)+
  theme(
    plot.margin = margin(7, 10, 7, 10, "pt"),
    legend.position = "inside",
    legend.justification.inside = c(0.98,0.92)
  )

## y_1
Sim_Density = data.frame("X_value" = seq(0,10,length.out = 1000))
Sim_Density$D1 = Marignal.distribution(x = Sim_Density$X_value, Type = "d", Num = "y_1")

## Plot
p3 = ggplot() +
  geom_histogram(
    data = Final_EC,
    binwidth = 0.6,
    fill = Sel_Colors[3],
    color = "#e9ecef",
    alpha = 0.6,
    aes(x = y_1, y = after_stat(density))
  ) +
  geom_path(data = Sim_Density,color = Sel_Colors[2],
            aes(x = X_value, y = D1))+
  scale_x_continuous(name = expression("2081-2100 "*Delta*italic(T["GL"])*" (°C relative to 1850-1900)")) +
  scale_y_continuous(name = "Probability density",breaks = seq(0,0.6,0.1)) +
  theme_figure1+
  coord_cartesian(xlim = c(2,10), ylim = c(0,0.6),expand = FALSE)+
  theme(
    plot.margin = margin(7, 10, 7, 10, "pt"),
    legend.position = "inside",
    legend.justification.inside = c(0.98,0.92)
  )


## Total Plot
p.total = plot_grid(p1, p2, p3, labels = "auto", nrow = 1)

## Saving
ggsave(
  filename = "Figures/Fig_3.pdf",
  plot = p.total,
  device = cairo_pdf,
  width = 11,
  height = 4
)

# End ---------------------------------------------------------------------


